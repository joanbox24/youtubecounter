MagiCubE - "Weather Station" & "YouTube Subscribe Counter" by MiguelBi on Thingiverse: https://www.thingiverse.com/thing:2633583

Summary:
The MagiCube (40mm x 40mm x 40mm)Inside (Weather Station): Wemos D1 mini (ESP8266) https://goo.gl/zFczWFSensor DHT22 https://goo.gl/ecfdX9Oled Display 1.3" https://goo.gl/WcwDCYDouble cable USB-MicroUSB: https://goo.gl/csQaanBreadboard: https://goo.gl/FHTv3aCable Dupont MM - MF - FF: https://goo.gl/nxEnMVMagnets: https://goo.gl/2q1Ma4YouTube: https://youtu.be/LRdSqQy3fBAhttps://youtu.be/gkihHl0sk2g